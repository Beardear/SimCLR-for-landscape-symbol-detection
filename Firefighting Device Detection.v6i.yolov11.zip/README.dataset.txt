# Firefighting Device Detection > 2023-11-07 11:15am
https://universe.roboflow.com/yaid-pzikt/firefighting-device-detection

Provided by a Roboflow user
License: BY-NC-SA 4.0

